package enums;

public enum UserType {
    CONSUMER, RETAIL, CHARITY
}
