package enums;

public enum PurchaseType {
    PURCHASE, DONATION
}
