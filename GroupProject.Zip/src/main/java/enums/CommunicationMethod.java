package enums;

public enum CommunicationMethod {
    EMAIL, PHONE
}
