package services;

public class EmailNotificationService implements NotificationService {
    @Override
    public void sendNotification(String recipient, String message) {
        // 이메일 알림 로직 구현
    }
}
