package services;

public interface NotificationService {
    void sendNotification(String recipient, String message);
}
