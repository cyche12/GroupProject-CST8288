package services;

public class SmsNotificationService implements NotificationService {
    @Override
    public void sendNotification(String recipient, String message) {
        // SMS 알림 로직 구현
    }
}
